PLEN - 3DModel for SolidWorks.
================================================================================
Copyright (c) 2015.
---
- [NAOHIRO HAYAISHI](http://earlystone.com/)
- [Ryotaro HAMANO](https://github.com/yurueater)
- [PLEN Project Company Ltd.](http://plen.jp)

Build enviroment.
---
- Windows 8.1
- SOLIDWORKS Professional 2015 x64 Edition SP3.0

License.
---
This material is released under the Creative Commons BY 4.0.