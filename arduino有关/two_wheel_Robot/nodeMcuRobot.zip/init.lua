dofile("init_t.lc")
