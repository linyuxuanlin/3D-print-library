var init = function() {
	window.addEventListener("keydown", onKeyDown, false);
	window.addEventListener("keyup", onKeyUp, false);

	keyW = false;
	keyA = false;
	keyS = false;
	keyD = false;
		
	oldrequest = ""
	
	//setInterval(function() {
	//	if (!keyW && !keyS && !keyA && !keyD) {
	//		get("/api/00", function(data) {
	//			console.log(data);
	//			oldrequest = "/api/00";
	//		});
	//	}
	//}, 1000);
}


  

function onKeyDown(event) {
	onKey(event, true);
}

function onKeyUp(event) {
	onKey(event, false);
}

function onKey(event, action) {
	var keyCode = event.keyCode;
	switch (keyCode) {
		case 68: //d
			keyD = action;
			break;
		case 83: //s
			keyS = action;
			break;
		case 65: //a
			keyA = action;
			break;
		case 87: //w
			keyW = action;
			break;
	}
	sendToRobot();
}

function sendToRobot() {
	var request = "/api/";
	if (!keyW && !keyS && !keyA && !keyD) {
		request += "00";
	}
	if ( keyW && !keyS && !keyA && !keyD) {
		request += "11";
	}
	if (!keyW &&  keyS && !keyA && !keyD) {
		request += "22";
	}
	if (!keyW && !keyS &&  keyA && !keyD) {
		request += "21";
	}
	if (!keyW && !keyS && !keyA &&  keyD) {
		request += "12";
	}
	if ( keyW && !keyS &&  keyA && !keyD) {
		request += "01";
	}
	if ( keyW && !keyS && !keyA &&  keyD) {
		request += "10";
	}
	if (!keyW &&  keyS &&  keyA && !keyD) {
		request += "02";
	}
	if (!keyW &&  keyS && !keyA &&  keyD) {
		request += "20";
	}
	
	if (oldrequest != request) {
		console.log(request);
		get(request, function(data) {
	   	    console.log(data);
	    });
		oldrequest = request;
	}
	
}

function get(uri, callback) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == XMLHttpRequest.DONE ) {
		    var state = xmlhttp.status;
            if ((state >= 200) || (state < 300)) {
                callback(xmlhttp.responseText);
            } else {
		        callback(null);
		    }           
        }
    }
    xmlhttp.open("GET", uri, true);
    xmlhttp.send();
}