
local function Server(port, callback)
  sv=net.createServer(net.TCP, 180)
  sv:listen(port, function(conn)
    conn:on("receive", function(conn, request) 
      collectgarbage()
      local start = string.find(request, "GET /")
      local ende  = string.find(request, " HTTP/1.")
      local req = string.sub(request, start+5, ende-1)
      conn:send("HTTP/1.1 200 OK\r\n")
      conn:send("Connection: close\r\n")
      conn:send("\r\n")
      callback(conn, req)
      conn:close()
    end)
    conn:on("disconnection",function(conn) 
    end)
  end) 
end
return Server

