print("start")
wifi.setmode(wifi.STATION)
wifi.sta.config("network","password")
print(wifi.sta.getip())

local m1f=false
local m1r=false
local m2f=false
local m2r=false

dofile("server.lc")(80, function(conn, request)
    if (request=="api/00") then
        conn:send(node.heap())
        m1f=false
        m1r=false
        m2f=false
        m2r=false
    elseif (request=="api/01") then
        conn:send(node.heap())
        m1f=false
        m1r=false
        m2f=true
        m2r=false
    elseif (request=="api/02") then
        conn:send(node.heap())
        m1f=false
        m1r=false
        m2f=false
        m2r=true
    elseif (request=="api/10") then
        conn:send(node.heap())
        m1f=true
        m1r=false
        m2f=false
        m2r=false
    elseif (request=="api/20") then
        conn:send(node.heap())
        m1f=false
        m1r=true
        m2f=false
        m2r=false
    elseif (request=="api/21") then
        conn:send(node.heap())
        m1f=false
        m1r=true
        m2f=true
        m2r=false
    elseif (request=="api/12") then
        conn:send(node.heap())
        m1f=true
        m1r=false
        m2f=false
        m2r=true
    elseif (request=="api/11") then
        conn:send(node.heap())
        m1f=true
        m1r=false
        m2f=true
        m2r=false
    elseif (request=="api/22") then
        conn:send(node.heap())
        m1f=false
        m1r=true
        m2f=false
        m2r=true
    elseif (request=="favicon.ico") then
        conn:send("err");
    elseif file.open(request, "r") then
        print("file open: "..request)
        local count = 0
        repeat
          collectgarbage()
          local line=file.read(256)
          if line then
            count=count+string.len(line)
            conn:send(line)
          end
        until not line    
        file.close()
        print(tostring(count).." bytes sent")
    else
        print("error")
    end
end)

local Stepper = dofile("stepper.lc")
local motor1 = Stepper(0,2,1,3)
local motor2 = Stepper(7,5,6,4)
tmr.alarm(0, 2, 1, function()
    collectgarbage()
    if (m1f) then
        motor1.stepForward()
    elseif (m1r) then
        motor1.stepBack()
    end
    if (m2f) then
        motor2.stepForward()
    elseif (m2r) then
        motor2.stepBack()
    end
end)

print("ende")
