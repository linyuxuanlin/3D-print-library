

local function Stepper(ap1, ap2, ap3, ap4)
    local self = {
        p1 = ap1,
        p2 = ap2,
        p3 = ap3,
        p4 = ap4
    }
    local state = 0

    gpio.mode(self.p1, gpio.OUTPUT);
    gpio.mode(self.p2, gpio.OUTPUT);
    gpio.mode(self.p3, gpio.OUTPUT);
    gpio.mode(self.p4, gpio.OUTPUT);
    gpio.write(self.p1, gpio.HIGH);
    gpio.write(self.p2, gpio.LOW);
    gpio.write(self.p3, gpio.LOW);
    gpio.write(self.p4, gpio.LOW);

    function self.stepForward()
        state = (state - 1) % 8
        self.setOutputs() 
    end
    function self.stepBack()
        state = (state + 1) % 8
        self.setOutputs() 
    end
    function self.setOutputs()
        if state==0 then
            gpio.write(self.p4, gpio.LOW);
        elseif state==1 then
            gpio.write(self.p2, gpio.HIGH);
        elseif state==2 then
            gpio.write(self.p1, gpio.LOW);
        elseif state==3 then
            gpio.write(self.p3, gpio.HIGH);
        elseif state==4 then
            gpio.write(self.p2, gpio.LOW);
        elseif state==5 then
            gpio.write(self.p4, gpio.HIGH);
        elseif state==6 then
            gpio.write(self.p3, gpio.LOW);
        elseif state==7 then
            gpio.write(self.p1, gpio.HIGH);
        end
    end
    return self
end
return Stepper
