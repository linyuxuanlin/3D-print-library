fileToExecute="run.lc"
l = file.list()
for k,v in pairs(l) do
  if k == fileToExecute then
    print("execute "..fileToExecute.." in 5 sec")
    print("  run 'tmr.stop(0)' to abort")
    tmr.alarm(0, 5000, 0, function()
      print("Executing ".. fileToExecute)
      dofile(fileToExecute)
    end)
  end
end
