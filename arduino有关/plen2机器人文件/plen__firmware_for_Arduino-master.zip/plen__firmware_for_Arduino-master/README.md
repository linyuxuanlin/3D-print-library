﻿PLEN2 - Firmware for Arduino (Atmega32u4)
================================================================================

Code name "Cytisus" (version 1.00) is now available!

Copyright (c) 2015.
---
- [Kazuyuki TAKASE](https://github.com/Guvalif)
- [PLEN Project Company Ltd.](http://plen.jp)

Build enviroment.
---
- Windows 8.1 Professional edition
- Windows 7 Home Premium
- Arduino IDE ver.1.6.0
- Sublime Text 2 ver.2.0.2
- [Stino](https://github.com/Robot-Will/Stino)
- [Arduino Unit](https://github.com/mmurdoch/arduinounit)

License.
---
This software is released under the MIT License.