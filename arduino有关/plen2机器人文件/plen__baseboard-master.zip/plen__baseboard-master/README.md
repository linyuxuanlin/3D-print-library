PLEN - Baseboard
================================================================================
Copyright (c) 2015.
---
- [NAOHIRO HAYAISHI](http://earlystone.com/)
- [PLEN Project Company Ltd.](http://plen.jp)

Build enviroment.
---
- Windows 8.1
- Eagle 6.60

License.
---
This material is released under the Creative Commons BY 4.0.

**Attention!**  
The schematic diagram of Arduino Micro in schematic file is licensed by Arduino. Please see the detail on their [web-site](https://www.arduino.cc/).
The schematic diagram of Multi-ServoMotor Interface, RS485 communication port and EEPROM is released under Creative Commons Attribution 4.0 International Public License.