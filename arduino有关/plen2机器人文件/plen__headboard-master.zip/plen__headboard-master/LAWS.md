Laws of PLEN
============

## English
You could use PLEN for every imaginable things, but, in that case, please observe the following laws strictly.

1. PLEN must not fight.
2. PLEN must not give someone a feeling of discomfort.
3. PLEN must be able to inherit its characteristics.

## Japanese
PLENはユーザの想像力の限り、あらゆる用途で使用していただいて構いません。ただしその際、必ず以下の項目が守られるようにしてください。

1. PLENは戦ってはならない。
2. PLENは不快感を与えてはならない。
3. PLENは自己の特徴を継承可能にしなければならない。