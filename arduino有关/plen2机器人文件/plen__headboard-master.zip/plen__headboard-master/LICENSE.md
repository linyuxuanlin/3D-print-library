<a rel="license" href="http://creativecommons.org/licenses/by/4.0/">
	<img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" />
</a>

&quot;<span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/StillImage" property="dct:title" rel="dct:type">PLEN - Head Board</span>&quot; is created by followings.
<ul>
	<li><a xmlns:cc="http://creativecommons.org/ns#" href="http://earlystone.com/" property="cc:attributionName" rel="cc:attributionURL">Naohiro HAYAISHI</a></li>
	<li><a xmlns:cc="http://creativecommons.org/ns#" href="http://plen.jp" property="cc:attributionName" rel="cc:attributionURL">PLEN Project Company Ltd.</a></li>
</ul>

This material is released under the <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons BY 4.0</a>.