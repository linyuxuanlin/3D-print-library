PLEN - baseboard.
================================================================================
Copyright (c) 2015.
---
- [NAOHIRO HAYAISHI](http://earlystone.com/)
- [PLEN Project Company Ltd.](http://plen.jp)

Build enviroment.
---
- Windows 8.1
- Eagle 6.60

License.
---
This material is released under the Creative Commons BY 4.0.

